// Geovanna Clara
function filterSelection(category) {
    const images = document.querySelectorAll('.image');
    if (category === 'all') {
        images.forEach(image => image.style.display = 'block');
    } else {
        images.forEach(image => {
            if (image.classList.contains(category)) {
                image.style.display = 'block';
            } else {
                image.style.display = 'none';
            }
        });
    }
}

