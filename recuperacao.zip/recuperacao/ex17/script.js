// Geovanna Clara
const loginForm = document.getElementById('loginForm');
const message = document.getElementById('message');

loginForm.addEventListener('submit', function(event) {
  event.preventDefault();
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  if (username === 'professor' && password === 'aula') {

    localStorage.setItem('isLoggedIn', 'true');
   
    window.location.href = 'entrou.html';
  } else {
    message.innerText = 'Invalid username or password';
  }
});

if (localStorage.getItem('isLoggedIn') === 'true') {
  window.location.href = 'index.html'; 
}
