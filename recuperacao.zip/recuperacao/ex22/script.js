// Geovanna Clara
document.getElementById('checkout-form').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const address = document.getElementById('address').value.trim();
    const city = document.getElementById('city').value.trim();
    const state = document.getElementById('state').value.trim();
    const zip = document.getElementById('zip').value.trim();
    const cardNumber = document.getElementById('card-number').value.trim();
    const expiryDate = document.getElementById('expiry-date').value.trim();
    const cvv = document.getElementById('cvv').value.trim();
    
    if (!name || !email || !address || !city || !state || !zip || !cardNumber || !expiryDate || !cvv) {
        alert('Por favor, preencha todos os campos.');
        return;
    }
    
    if (!validateEmail(email)) {
        alert('Por favor, insira um email válido.');
        return;
    }

    if (!validateCardNumber(cardNumber)) {
        alert('Por favor, insira um número de cartão válido.');
        return;
    }

    if (!validateExpiryDate(expiryDate)) {
        alert('Por favor, insira uma data de validade válida.');
        return;
    }

    if (!validateCVV(cvv)) {
        alert('Por favor, insira um CVV válido.');
        return;
    }

    alert('Pagamento realizado com sucesso!');
});

function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function validateCardNumber(cardNumber) {
    const re = /^\d{16}$/;
    return re.test(cardNumber);
}

function validateExpiryDate(expiryDate) {
    const re = /^(0[1-9]|1[0-2])\/\d{2}$/;
    return re.test(expiryDate);
}

function validateCVV(cvv) {
    const re = /^\d{3,4}$/;
    return re.test(cvv);
}
