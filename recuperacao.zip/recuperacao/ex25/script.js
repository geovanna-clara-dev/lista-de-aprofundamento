// Geovanna Clara
document.addEventListener('DOMContentLoaded', function() {
    const questions = document.querySelectorAll('.question');
  
    questions.forEach(function(question) {
      question.addEventListener('click', function() {
        questions.forEach(function(q) {
          if (q !== question) {
            q.classList.remove('active');
            q.nextElementSibling.classList.remove('show');
          }
        });
        question.classList.toggle('active');
        question.nextElementSibling.classList.toggle('show');
      });
    });
  });
  