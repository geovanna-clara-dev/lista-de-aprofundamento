// Geovanna Clara
const form = document.getElementById('contactForm');
form.addEventListener('submit', function(event) {
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;
    const errorElement = document.getElementById('error');

    if (name === '' || email === '' || message === '') {
        errorElement.innerText = 'Por favor, preencha todos os campos.';
        event.preventDefault();
    }
});
