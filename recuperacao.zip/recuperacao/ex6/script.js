// Geovanna Clara
document.getElementById("comment-button").addEventListener("click", function() {
    
    var commentText = document.getElementById("comment").value;

    if (commentText.trim() === "") {
        alert("Por favor, digite um comentário.");
        return;
    }

   
    var commentElement = document.createElement("li");
    commentElement.textContent = commentText;

    var commentsList = document.getElementById("comments");
    commentsList.appendChild(commentElement);
    
    document.getElementById("comment").value = "";
});
