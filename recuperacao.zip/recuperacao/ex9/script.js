// Geovanna Clara
document.getElementById('animateButton').addEventListener('click', function() {
    var button = this;
    button.classList.remove('animated');
    
    void button.offsetWidth;
    
    button.classList.add('animated');
});
